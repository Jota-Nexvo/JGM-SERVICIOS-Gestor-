# Handoff: JGM SERVICIOS — Gestor de clientes y cobros

## Cómo usar este paquete con Claude Code (leer primero)

Este paquete es para que **Claude Code** implemente la app como proyecto real. Trabajá **por fases, en este orden**, una fase por conversación/sesión corta. Al terminar cada fase, probá y recién después pedí la siguiente. Prompt inicial sugerido:

> Lee README.md de esta carpeta. Implementá SOLO la Fase 1 del plan. El archivo "JGM Gestor.dc.html" es la referencia de diseño y comportamiento (abrilo en un navegador junto a support.js para verlo funcionar). No avances a otras fases hasta que yo lo pruebe.

Y luego: "Ahora implementá la Fase 2", etc.

## Overview

App personal para JGM SERVICIOS (perforación de pozos artesianos, mantenimiento, venta de motobombas sumergibles, pesca/recuperación de equipos trancados en pozos) en Paraguay. Gestiona **clientes, trabajos y cobros a crédito**: cuánto debe cada cliente, fechas de cobro pactadas, avisos de vencimiento, historial de pagos parciales y fotos de cada trabajo. Un solo usuario (el dueño), principalmente desde el celular, sin servidor: todos los datos viven en el dispositivo.

## Sobre los archivos de diseño

- `JGM Gestor.dc.html` + `support.js`: **prototipo funcional completo en HTML** (referencia). Abrir el .html en un navegador con support.js al lado; funciona de verdad (datos de ejemplo precargados). NO es código de producción para copiar: hay que **recrearlo** en el stack elegido.
- `assets/jgm-logo.png`: logo real. Usarlo en sidebar (escritorio), header (móvil) y Ajustes.
- Stack objetivo: no existe codebase previo. Recomendado: **PWA simple** (React + Vite o incluso vanilla JS) con `localStorage` + `IndexedDB`, instalable en Android ("Agregar a pantalla de inicio"), 100% offline. Sin backend.

## Fidelidad

**Alta (hifi).** El prototipo es el diseño final: colores, tipografía, espaciados, copys en español (voseo paraguayo) e interacciones deben recrearse tal cual del HTML de referencia. Ante cualquier duda, el HTML manda.

## Modelo de datos (localStorage `jgm_gestor_v1`)

```js
{
  clients: [{ id, name, phone, address, ci, notes, createdAt }],
  jobs: [{
    id, clientId, desc, category, date,          // fecha del trabajo (ISO yyyy-mm-dd)
    price,                                        // ₲, editable después (descuentos)
    credit: true|false,                           // contado o crédito
    payments: [{ id, amount, date, note }],       // pagos parciales libres (la seña es el primer pago)
    dueDates: [{ id, date }],                     // una o varias fechas de cobro
    remindDays: null|number,                      // override del aviso; null = usa el global
    photos: [{ id, date }],                       // los binarios van en IndexedDB
    paid: bool                                    // true solo cuando saldo == 0 (recalcular siempre)
  }],
  settings: { categories: [...], remindDays: 3, notifEnabled: bool },
  demo: bool
}
```

- Saldo de un trabajo = `price − Σ payments`. Se recalcula en cada mutación; `paid` se marca solo al llegar a 0.
- Fotos: IndexedDB `jgm_fotos_v1`, store `fotos`, clave = id de foto, valor = dataURL JPEG (reescalado a máx. 1280px, calidad 0.72). Borrar trabajo/cliente/todo borra también sus fotos.
- Moneda: guaraníes sin decimales, formato `₲ 14.500.000` (puntos de miles).
- Seed de datos de ejemplo la primera vez (`demo: true`); Ajustes permite restablecerlo o borrar todo.

## Pantallas (4 + modales) — replicar del prototipo

1. **Inicio**: tarjetas Total por cobrar / Vencidos / Hoy; mes en DOS números (realizado = valor de trabajos del mes; cobrado = dinero recibido); mayores deudores; últimos trabajos. Campanita con contador (vencidos + hoy).
2. **Clientes**: buscador; secciones ① mayor deuda ② últimos trabajos ③ último movimiento + listado alfabético completo. Ficha del cliente: datos, botón WhatsApp (`wa.me/595...`, quitar 0 inicial del número), trabajos expandibles con pagos, fotos (agregar/visor a pantalla completa/borrar), fechas de cobro, acciones (cobrar, editar, borrar con confirmación de doble toque).
3. **Cobros**: agenda de fechas de cobro agrupada: Vencidos / Hoy / Próximos / Futuros, con acceso directo a registrar pago.
4. **Ajustes**: categorías editables, aviso anticipado global (días), notificaciones del navegador (máx. 1/día), exportar/importar respaldo JSON (incluye fotos en clave `photos`), restablecer datos de ejemplo, borrar todo, logo + versión.

- Modales: nuevo/editar cliente, nuevo/editar trabajo (con seña), registrar pago, posponer/editar fecha de cobro.
- Sin PIN, sin recibos, sin gastos (los gastos/estado de resultados son una fase futura explícitamente pospuesta — NO construir).

## Interacciones clave

- Responsive en un solo layout: **≥880px** sidebar oscura izquierda + topbar; **<880px** tab bar inferior de 4 ítems + FAB "+" (nuevo trabajo/cliente/pago). Targets táctiles ≥44px.
- Borrados destructivos: patrón "tocá otra vez para confirmar" (2º toque en ≤4s).
- Notificaciones: pedir permiso desde Ajustes; al abrir la app, si hay vencidos/hoy y no se notificó hoy, mostrar una (guardar última fecha notificada).
- Fotos: input file `accept="image/*" multiple`, comprimir en canvas antes de guardar; visor a pantalla completa con prev/next, contador y eliminar.

## Design tokens

- Colores: acento `#2B57C8` · oscuro sidebar `#232A56` · fondo `#F3F5FA` · superficie `#FFFFFF` · borde `#E2E8F4` / `#EDF1F8` · texto `#1B2340` · secundario `#6B7690` · éxito `#1F8A5B` · peligro `#D2543A` · aviso `#B57A1F`.
- Tipografía: títulos/UI **Instrument Sans** (o sistema), números/montos **IBM Plex Mono** 600-700. Texto mínimo 14px móvil.
- Radios: cards 12-14px, botones 9-10px, pills 999px. Sombras suaves (`0 1px 2px rgba(20,30,70,.06)`).

## Plan de trabajo por fases (ejecutar de a una)

1. **Fase 1 — Esqueleto + datos**: proyecto PWA, modelo de datos + persistencia localStorage, seed de ejemplo, layout responsive (sidebar/tab bar + FAB), navegación entre las 4 pantallas vacías, logo integrado. ✔ Criterio: navego en móvil y escritorio, datos sobreviven al recargar.
2. **Fase 2 — Clientes**: lista con secciones + buscador, ficha, alta/edición/borrado, WhatsApp. ✔ Criterio: CRUD completo de clientes.
3. **Fase 3 — Trabajos y pagos**: alta/edición de trabajos (categoría, precio, crédito/contado, seña, fechas de cobro), pagos parciales, recálculo de saldo, historial. ✔ Criterio: un trabajo a crédito se salda con varios pagos y pasa a "Pagado".
4. **Fase 4 — Inicio + Cobros + avisos**: métricas del Inicio (realizado/cobrado del mes), agenda de cobros agrupada, campanita, posponer fechas, notificaciones (1/día). ✔ Criterio: números cuadran con los datos.
5. **Fase 5 — Fotos**: IndexedDB, agregar desde el trabajo, visor, borrado en cascada. ✔ Criterio: fotos sobreviven recarga y se borran con el trabajo.
6. **Fase 6 — Ajustes + respaldo**: categorías, aviso global, exportar/importar JSON con fotos, restablecer/borrar todo. ✔ Criterio: exporto, borro todo, importo y queda igual.
7. **Fase 7 — Pulido + PWA**: manifest + service worker offline, icono con el logo, revisión visual fina contra el prototipo.

## Assets

- `assets/jgm-logo.png` (logo real, único asset).
- Iconos: SVG inline de trazo simple (ver prototipo), no librerías pesadas.

## Archivos del paquete

- `README.md` — este plan.
- `JGM Gestor.dc.html` — prototipo de referencia (abrir en navegador).
- `support.js` — runtime necesario para que el prototipo abra tal cual.
- `assets/jgm-logo.png` — logo.
